import {readPrivateJson,writePrivateJson,removePrivateJson} from './privateJson';
import type {PendingPayment} from '../../application/user/payments/paymentRules';
const key=(owner:string)=>'rotihai.pending-payment.'+owner;
export const pendingPayment={read:(owner:string)=>readPrivateJson<PendingPayment>(key(owner)),save:(owner:string,payment:PendingPayment)=>writePrivateJson(key(owner),payment),clear:(owner:string)=>removePrivateJson(key(owner))};
