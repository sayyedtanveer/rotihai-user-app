import React, { type PropsWithChildren } from 'react';
import {DeliveryAreaProvider} from '../location/DeliveryAreaProvider';

// Provider boundary matching the chef app. Add customer providers during implementation.
export function AppProviders({ children }: PropsWithChildren) {
  return <DeliveryAreaProvider>{children}</DeliveryAreaProvider>;
}
