import type { CartItem, Category, Chef, Product, ProductOffer } from '../../../core/api/models';
type Request = <T>(path: string) => Promise<T>;
export type SavedBasket = {chefId?: string | null; categoryId?: string | null; items: Array<Partial<CartItem>>};
export async function restoreCartItems(saved: SavedBasket, request: Request): Promise<CartItem[]> {
  if (!Array.isArray(saved.items) || !saved.items.length || saved.items.length > 100) throw new Error('This saved basket has no valid items.');
  const categories = await request<Category[]>('/api/categories');
  return Promise.all(saved.items.map(async old => {
    if (!old.id || !Number.isInteger(old.quantity) || old.quantity! <= 0) throw new Error('The saved quantity is invalid. Choose your items again.');
    const [product, promotion] = await Promise.all([
      request<Product>('/api/products/' + encodeURIComponent(old.id)),
      request<{offer: ProductOffer | null}>('/api/products/' + encodeURIComponent(old.id) + '/offer'),
    ]);
    if ((saved.chefId && saved.chefId !== product.chefId) || (saved.categoryId && saved.categoryId !== product.categoryId)) throw new Error(product.name + ' has moved to another menu. Add it again from the menu.');
    const chef = await request<Chef>('/api/chefs/' + encodeURIComponent(product.chefId));
    const variant = product.variants?.find(v => v.id === old.variantId);
    if (!product.isAvailable || (product.hasVariants && !old.variantId) || (old.variantId && (!variant?.isActive || !variant.isAvailable))) throw new Error(product.name + ' is unavailable. Choose another dish from the menu.');
    const category = categories.find(c => c.id === product.categoryId);
    if (!category) throw new Error('This menu is no longer available.');
    const activeOffer = promotion.offer && promotion.offer.isActive !== false && (!promotion.offer.validUntil || Date.parse(promotion.offer.validUntil) > Date.now()) ? promotion.offer : null;
    return {key: product.id + ':' + (variant?.id || ''), id: product.id, name: product.name,
      chefId: product.chefId, chefName: chef.name, categoryId: product.categoryId, categoryName: category.name,
      quantity: old.quantity!, price: Number(variant?.price ?? product.price), image: product.image,
      variantId: variant?.id, variantName: variant?.name, stockQuantity: variant?.stockQuantity ?? product.stockQuantity,
      effectiveMode: product.effectiveMode || product.fulfillmentMode || 'instant',
      offerPercentage: product.offerPercentage, offer: variant ? null : activeOffer,
      specialInstructions: old.specialInstructions,
    };
  }));
}
