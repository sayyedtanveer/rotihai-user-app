import type { CartItem, Product, ProductOffer, Slot } from '../../../core/api/models';
import { lineTotal, money } from './cartRules';
export function validateFreshItem(item: CartItem, product: Product, offer: ProductOffer | null) {
  const variant = product.variants?.find(v => v.id === item.variantId);
  if (!product.isAvailable || product.chefId !== item.chefId || product.categoryId !== item.categoryId ||
      (product.hasVariants && !item.variantId) || (item.variantId && (!variant?.isActive || !variant.isAvailable)) ||
      (variant?.stockQuantity ?? product.stockQuantity) < item.quantity)
    throw new Error(item.name + ' is no longer available in that quantity. Update your cart.');
  const activeOffer = !item.variantId && offer && offer.isActive !== false && (!offer.validUntil || Date.parse(offer.validUntil) > Date.now()) ? offer : null;
  if (activeOffer?.maxOrderQuantity != null && item.quantity > activeOffer.maxOrderQuantity)
    throw new Error(item.name + ' now has a lower quantity limit. Update your cart.');
  const fresh = { ...item, price: Number(variant?.price ?? product.price), offerPercentage: product.offerPercentage, offer: activeOffer };
  if (money(fresh.price) !== money(item.price) || lineTotal(fresh) !== lineTotal(item))
    throw new Error(item.name + ' has a new price or offer. Remove it from your basket and add it again.');
  if (product.effectiveMode && product.effectiveMode !== item.effectiveMode)
    throw new Error(item.name + ' has a new delivery mode. Add it to your basket again.');
}
export function slotTiming(slot: Slot, date: string, now = Date.now()) {
  const starts = Date.parse(date + 'T' + slot.startTime + ':00+05:30');
  const cutoff = starts - Math.max(0, slot.cutoffHoursBefore || 0) * 3600000;
  return { ended: !Number.isFinite(starts) || now >= starts, late: now >= cutoff, cutoff };
}
