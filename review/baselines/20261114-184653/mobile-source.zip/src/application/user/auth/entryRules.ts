// Contact capture is deliberately separate from authenticated identity.
export function normalizeProvisionalPhone(value:string){const digits=value.replace(/\D/g,'').replace(/^91(?=\d{10}$)/,'');if(!/^[6-9]\d{9}$/.test(digits))throw new Error('Enter a valid 10-digit Indian mobile number.');return digits;}
export function initialCustomerStep(hasSession:boolean,phone:string|null):'home'|'phone'{return hasSession||!!phone?'home':'phone';}
