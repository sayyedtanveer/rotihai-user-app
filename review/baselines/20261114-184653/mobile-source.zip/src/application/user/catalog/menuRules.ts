import type { Category, Chef, Product, CartItem } from '../../../core/api/models';
export function isKitchenOrderable(chef?: Chef) { return !!chef && chef.isActive !== false && (chef.isCurrentlyOpen ?? chef.isActive) === true; }
export function kitchenStatus(chef: Chef) { return isKitchenOrderable(chef) ? 'Accepting orders' : chef.isActive === false ? 'Currently unavailable' : 'Currently closed'; }
export function matchesCategory(chef: Chef, products: Product[], categoryId?: string) {
  return !categoryId || chef.categoryId === categoryId || chef.categoryIds?.includes(categoryId) || products.some(p => p.chefId === chef.id && p.categoryId === categoryId);
}
export function groupMenu(products: Product[], categories: Category[] = [], includeCategory = false) {
  const groups = new Map<string, { key: string; title: string; order: number; data: Product[] }>();
  for (const product of products) {
    const section = product.section?.trim() || 'Others';
    const category = categories.find(c => c.id === product.categoryId);
    const key = includeCategory ? product.categoryId + ':' + section : section;
    if (!groups.has(key)) groups.set(key, { key, title: includeCategory ? (category?.name || 'Menu') + ' · ' + section : section, order: product.section?.trim() ? product.sectionOrder ?? 0 : 999, data: [] });
    groups.get(key)!.data.push(product);
  }
  return [...groups.values()].sort((a,b) => a.order-b.order || a.title.localeCompare(b.title)).map(g => ({ ...g, data: [...g.data].sort((a,b) => (a.sortOrder ?? 0)-(b.sortOrder ?? 0) || a.name.localeCompare(b.name)) }));
}
export function cartItemIssue(item: CartItem, products: Product[], chefs: Chef[]): string | null {
  const chef = chefs.find(c=>c.id===item.chefId), product = products.find(p=>p.id===item.id);
  if (!chef) return 'Not available in this delivery area';
  if (chef.isActive === false) return 'Kitchen currently unavailable';
  if (!isKitchenOrderable(chef)) return 'Kitchen currently closed';
  if (!product?.isAvailable) return 'Dish currently unavailable';
  if (item.variantId) {
    const variant=product.variants?.find(v=>v.id===item.variantId);
    if (!variant?.isActive || !variant.isAvailable) return 'Selected size is unavailable';
    if (item.quantity>variant.stockQuantity) return 'Selected quantity is out of stock';
  } else if (item.quantity>product.stockQuantity) return 'Selected quantity is out of stock';
  return null;
}
