import React,{useCallback,useState} from 'react';
import {useFocusEffect} from '@react-navigation/native';
import {useCustomer} from '../../../core/providers/CustomerProvider';
import {pendingPayment} from '../../../core/storage/pendingPayment';
import type {PendingPayment} from '../../../application/user/payments/paymentRules';
import {useAppNavigation} from '../navigation/types';
import {Card,Heading,Body,Button,currency} from './UI';
export function SavedPaymentCard(){
 const {user,token}=useCustomer(),nav=useAppNavigation(),[saved,setSaved]=useState<PendingPayment|null>(null);
 useFocusEffect(useCallback(()=>{let alive=true;if(token)void pendingPayment.read(user.id).then(p=>{if(alive)setSaved(p);}).catch(()=>{});else setSaved(null);return()=>{alive=false;};},[token,user.id]));
 if(!saved||['backend_recorded','closed'].includes(saved.phase))return null;
 return <Card><Heading>Your checkout is saved</Heading><Body muted>{currency(saved.amount)} · Check your existing order before paying again.</Body><Button title="Resume checkout & check status" secondary onPress={()=>nav.navigate('Payment',{id:saved.id,kind:saved.kind,amount:saved.amount})}/></Card>;
}
