// Brand colors and typography adapted from the RotiHai web Warm Roti theme.
export const theme = {
 bg:'#faf8f5',surface:'#ffffff',ink:'#30251f',muted:'#82746b',primary:'#bc6b1d',
 pale:'#fff3e2',border:'#eee7df',danger:'#b63c34',accent:'#f97316',gold:'#fbbf24',success:'#20724d',
 font:'Inter_400Regular',medium:'Inter_500Medium',semibold:'Inter_600SemiBold',bold:'Inter_700Bold',display:'Inter_800ExtraBold',
};
